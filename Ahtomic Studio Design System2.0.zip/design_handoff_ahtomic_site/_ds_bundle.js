/* @ds-bundle: {"format":4,"namespace":"AhtomicStudioDesignSystem_31497d","components":[{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Tabs","sourcePath":"components/display/Tabs.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Tooltip","sourcePath":"components/display/Tooltip.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"ProjectCard","sourcePath":"components/marketing/ProjectCard.jsx"},{"name":"SectionLabel","sourcePath":"components/marketing/SectionLabel.jsx"},{"name":"Wordmark","sourcePath":"components/marketing/Wordmark.jsx"}],"sourceHashes":{"components/display/Badge.jsx":"2d4932180627","components/display/Card.jsx":"9ea9d135b9b1","components/display/Tabs.jsx":"70f35dc31e37","components/display/Tag.jsx":"948eb226e4fd","components/display/Tooltip.jsx":"553dedb8a011","components/feedback/Dialog.jsx":"4ee1cc933aa7","components/feedback/Toast.jsx":"3a324eea4c2f","components/forms/Button.jsx":"8a7c5ab11c9d","components/forms/Checkbox.jsx":"1380ecdf025d","components/forms/IconButton.jsx":"f9dd3b5d8034","components/forms/Input.jsx":"ea231733d286","components/forms/Radio.jsx":"1ae9e3293d2b","components/forms/Select.jsx":"c46e3b4718d5","components/forms/Switch.jsx":"03e7d0baa265","components/marketing/ProjectCard.jsx":"21a3022c4639","components/marketing/SectionLabel.jsx":"69ad7c8aa777","components/marketing/Wordmark.jsx":"67be232afa19","ui_kits/admin/AdminAppearance.jsx":"fdf0f2c32bde","ui_kits/admin/AdminPages.jsx":"9dd902c29803","ui_kits/admin/AdminProjects.jsx":"887f062abf84","ui_kits/admin/admin-shared.jsx":"d542fb42e7e7","ui_kits/website/About.jsx":"5384cbc0e84c","ui_kits/website/Contact.jsx":"d1ab3c3ce41c","ui_kits/website/Home.jsx":"b3b936dcc37a","ui_kits/website/Services.jsx":"da3a0c5bf2dd","ui_kits/website/Work.jsx":"a4e4a10909e2","ui_kits/website/shared.jsx":"ae78cd2bb223"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AhtomicStudioDesignSystem_31497d = window.AhtomicStudioDesignSystem_31497d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/display/Badge.jsx
try { (() => {
function Badge({
  tone = "neutral",
  dot,
  children,
  style
}) {
  const toneCls = tone === "neutral" ? "" : ` ah-badge--${tone}`;
  return /*#__PURE__*/React.createElement("span", {
    className: `ah-badge${toneCls}`,
    style: style
  }, dot && /*#__PURE__*/React.createElement("span", {
    className: "ah-badge__dot"
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function Card({
  interactive,
  padding = "md",
  href,
  onClick,
  children,
  style,
  className
}) {
  const cls = `ah-card${interactive || href || onClick ? " ah-card--interactive" : ""} ah-card--pad-${padding}${className ? " " + className : ""}`;
  if (href) return /*#__PURE__*/React.createElement("a", {
    className: cls,
    href: href,
    style: {
      display: "block",
      textDecoration: "none",
      color: "inherit",
      ...style
    }
  }, children);
  return /*#__PURE__*/React.createElement("div", {
    className: cls,
    onClick: onClick,
    style: style
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  style
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? tabs[0]);
  const active = value !== undefined ? value : internal;
  const pick = t => {
    if (value === undefined) setInternal(t);
    if (onChange) onChange(t);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "ah-tabs",
    role: "tablist",
    style: style
  }, tabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    className: "ah-tabs__tab",
    role: "tab",
    "aria-selected": t === active,
    onClick: () => pick(t)
  }, t)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function Tag({
  onRemove,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "ah-tag",
    style: style
  }, children, onRemove && /*#__PURE__*/React.createElement("button", {
    onClick: onRemove,
    "aria-label": "Remove"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18M6 6l12 12"
  }))));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/display/Tooltip.jsx
try { (() => {
function Tooltip({
  text,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "ah-tooltip-wrap",
    tabIndex: 0,
    style: style
  }, children, /*#__PURE__*/React.createElement("span", {
    className: "ah-tooltip",
    role: "tooltip"
  }, text));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open,
  title,
  description,
  onClose,
  actions,
  children,
  style
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "ah-dialog-scrim",
    onClick: e => {
      if (e.target === e.currentTarget && onClose) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ah-dialog",
    role: "dialog",
    "aria-modal": "true",
    style: style
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 600,
      letterSpacing: "var(--tracking-tight)",
      marginBottom: 8
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 16px",
      fontSize: 14,
      color: "var(--text-secondary)",
      lineHeight: 1.55
    }
  }, description), children, actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 10,
      marginTop: 20
    }
  }, actions)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  tone = "neutral",
  children,
  onDismiss,
  style
}) {
  const toneCls = tone === "neutral" ? "" : ` ah-toast--${tone}`;
  return /*#__PURE__*/React.createElement("div", {
    className: `ah-toast${toneCls}`,
    role: "status",
    style: style
  }, /*#__PURE__*/React.createElement("span", {
    className: "ah-toast__bar"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, children), onDismiss && /*#__PURE__*/React.createElement("button", {
    onClick: onDismiss,
    "aria-label": "Dismiss",
    style: {
      all: "unset",
      cursor: "pointer",
      lineHeight: 0,
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18M6 6l12 12"
  }))));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function Button({
  variant = "primary",
  size = "md",
  disabled,
  children,
  onClick,
  href,
  style
}) {
  const cls = `ah-btn ah-btn--${size} ah-btn--${variant}`;
  if (href) {
    return /*#__PURE__*/React.createElement("a", {
      className: cls,
      href: href,
      style: style,
      "aria-disabled": disabled || undefined
    }, children);
  }
  return /*#__PURE__*/React.createElement("button", {
    className: cls,
    disabled: disabled,
    onClick: onClick,
    style: style
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: `ah-check${disabled ? " ah-check--disabled" : ""}`,
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ah-check__box"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  }))), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function IconButton({
  variant = "secondary",
  size = "md",
  disabled,
  label,
  children,
  onClick,
  style
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: `ah-btn ah-iconbtn ah-btn--${size} ah-btn--${variant}`,
    disabled: disabled,
    onClick: onClick,
    "aria-label": label,
    title: label,
    style: style
  }, children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  textarea,
  style,
  ...rest
}) {
  const cls = `ah-input${error ? " ah-input--error" : ""}`;
  const control = textarea ? /*#__PURE__*/React.createElement("textarea", _extends({
    className: cls
  }, rest)) : /*#__PURE__*/React.createElement("input", _extends({
    className: cls
  }, rest));
  return /*#__PURE__*/React.createElement("label", {
    className: "ah-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "ah-field__label"
  }, label), control, (error || hint) && /*#__PURE__*/React.createElement("span", {
    className: `ah-field__hint${error ? " ah-field__hint--error" : ""}`
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: `ah-check ah-check--radio${disabled ? " ah-check--disabled" : ""}`,
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ah-check__box"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ah-check__dot"
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  hint,
  options = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "ah-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "ah-field__label"
  }, label), /*#__PURE__*/React.createElement("select", _extends({
    className: "ah-input"
  }, rest), options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), hint && /*#__PURE__*/React.createElement("span", {
    className: "ah-field__hint"
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  label,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: `ah-switch${disabled ? " ah-switch--disabled" : ""}`,
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "ah-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ah-switch__thumb"
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/marketing/ProjectCard.jsx
try { (() => {
function ProjectCard({
  title,
  meta,
  image,
  imageAlt,
  href = "#",
  onClick,
  style
}) {
  return /*#__PURE__*/React.createElement("a", {
    className: "ah-projectcard",
    href: href,
    onClick: onClick,
    style: style
  }, /*#__PURE__*/React.createElement("img", {
    className: "ah-projectcard__img",
    src: image,
    alt: imageAlt || title
  }), /*#__PURE__*/React.createElement("div", {
    className: "ah-projectcard__body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ah-projectcard__title"
  }, title), /*#__PURE__*/React.createElement("span", {
    className: "ah-projectcard__arrow"
  }, "\u2197")), meta && /*#__PURE__*/React.createElement("div", {
    className: "ah-projectcard__meta"
  }, meta));
}
Object.assign(__ds_scope, { ProjectCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/ProjectCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/SectionLabel.jsx
try { (() => {
function SectionLabel({
  index,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ah-sectionlabel",
    style: style
  }, index && /*#__PURE__*/React.createElement("span", {
    className: "ah-sectionlabel__index"
  }, index), /*#__PURE__*/React.createElement("span", {
    className: "ah-sectionlabel__text"
  }, children));
}
Object.assign(__ds_scope, { SectionLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/SectionLabel.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Wordmark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Wordmark({
  size = 20,
  sub,
  href = "#",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    className: "ah-wordmark",
    href: href,
    style: {
      fontSize: size,
      display: "inline-flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", null, "Ahtomic", /*#__PURE__*/React.createElement("span", {
    className: "ah-wordmark__dot"
  }, ".")), sub && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontWeight: 400,
      fontSize: Math.max(9, Math.round(size * 0.3)),
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, sub));
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Wordmark.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/AdminAppearance.jsx
try { (() => {
const {
  Input,
  Switch,
  Button,
  Radio
} = window.AhtomicStudioDesignSystem_31497d;
const ACCENT_CHOICES = [{
  name: "Signal red",
  value: "#ff3b2f"
}, {
  name: "Crimson",
  value: "#e03e36"
}, {
  name: "Coral",
  value: "#ff6a55"
}, {
  name: "Deep red",
  value: "#e02318"
}];
function AppearancePreview({
  draft
}) {
  const a = draft.appearance;
  return /*#__PURE__*/React.createElement("div", {
    className: "ah-card",
    style: {
      padding: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      padding: "34px 26px 38px",
      overflow: "hidden"
    }
  }, a.grid && /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "linear-gradient(rgba(217,220,226,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(217,220,226,0.05) 1px, transparent 1px)",
      backgroundSize: "36px 36px",
      maskImage: "linear-gradient(180deg, black, transparent 90%)",
      WebkitMaskImage: "linear-gradient(180deg, black, transparent 90%)"
    }
  }), a.glow && /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(320px 160px at 50% 115%, " + a.accent + "2e, transparent 70%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.15
    }
  }, "Websites and apps, built", " ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      letterSpacing: 0,
      ...(a.sheen ? {
        background: "var(--silver-sheen)",
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        color: "transparent"
      } : {})
    }
  }, "properly"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: a.accent
    }
  }, ".")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      padding: "7px 13px",
      borderRadius: "var(--radius-md)",
      background: a.accent,
      color: "#fff",
      fontSize: 11,
      fontWeight: 600
    }
  }, "Start a project"), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: "7px 13px",
      borderRadius: "var(--radius-md)",
      border: "1px solid var(--line-2)",
      color: "var(--text-secondary)",
      fontSize: 11,
      fontWeight: 500
    }
  }, "See the work")))));
}
function AppearanceEditor({
  draft,
  update
}) {
  const a = draft.appearance;
  const setBool = field => e => update(d => {
    d.appearance[field] = e.target.checked;
  });
  return /*#__PURE__*/React.createElement(EditorLayout, {
    preview: /*#__PURE__*/React.createElement(AppearancePreview, {
      draft: draft
    })
  }, /*#__PURE__*/React.createElement(SectionCard, {
    title: "Accent color",
    hint: "Used for buttons, links, the headline period, and background glows."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, ACCENT_CHOICES.map(c => {
    const active = a.accent === c.value;
    return /*#__PURE__*/React.createElement("button", {
      key: c.value,
      type: "button",
      onClick: () => update(d => {
        d.appearance.accent = c.value;
      }),
      "aria-pressed": active,
      "aria-label": "Set accent color to " + c.name,
      style: {
        cursor: "pointer",
        font: "inherit",
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 14px 8px 8px",
        borderRadius: 999,
        border: "1px solid " + (active ? "var(--line-accent)" : "var(--line-1)"),
        background: active ? "var(--accent-subtle)" : "transparent",
        color: active ? "var(--text-body)" : "var(--text-muted)",
        fontSize: 13,
        fontWeight: 500
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 22,
        height: 22,
        borderRadius: "50%",
        background: c.value,
        boxShadow: active ? "0 0 0 2px var(--surface-page), 0 0 0 3.5px " + c.value : "none"
      }
    }), c.name);
  }))), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Background effects",
    hint: "All effects are lightweight and switch off automatically for visitors who prefer reduced motion."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Red glow behind page content",
    checked: a.glow,
    onChange: setBool("glow")
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Faint background grid",
    checked: a.grid,
    onChange: setBool("grid")
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Film grain texture",
    checked: a.grain,
    onChange: setBool("grain")
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Cursor glow (follows the mouse)",
    checked: a.cursorGlow,
    onChange: setBool("cursorGlow")
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Silver shine on the italic headline word",
    checked: a.sheen,
    onChange: setBool("sheen")
  }))), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Motion",
    hint: "How much things move as visitors scroll and navigate."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 20,
      flexWrap: "wrap"
    }
  }, ["Full", "Subtle", "Off"].map(m => /*#__PURE__*/React.createElement(Radio, {
    key: m,
    name: "motion",
    label: m,
    checked: a.motion === m,
    onChange: () => update(d => {
      d.appearance.motion = m;
    })
  })))));
}
function SettingsEditor({
  draft,
  update
}) {
  const s = draft.settings;
  const set = field => e => update(d => {
    d.settings[field] = e.target.value;
  });
  return /*#__PURE__*/React.createElement(EditorLayout, null, /*#__PURE__*/React.createElement(SectionCard, {
    title: "Contact details",
    hint: "Shown in the footer and used by the contact form."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Contact email",
    type: "email",
    value: s.email,
    onChange: set("email")
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Location line",
    value: s.location,
    onChange: set("location")
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Reply-time promise",
    hint: "Shown on the contact page, e.g. \"Replies within 2 days\"",
    value: s.replyTime,
    onChange: set("replyTime"),
    style: {
      maxWidth: 420
    }
  })), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Footer"
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Footer tagline",
    value: s.footerTagline,
    onChange: set("footerTagline")
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Copyright line",
    value: s.copyright,
    onChange: set("copyright"),
    style: {
      maxWidth: 420
    }
  })), /*#__PURE__*/React.createElement(SectionCard, {
    title: "Browser tab",
    hint: "What shows in search results and the browser tab."
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Site title",
    value: s.siteTitle,
    onChange: set("siteTitle")
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Site description",
    textarea: true,
    rows: 2,
    value: s.siteDescription,
    onChange: set("siteDescription")
  })));
}
Object.assign(window, {
  AppearanceEditor,
  SettingsEditor
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/AdminAppearance.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/AdminPages.jsx
try { (() => {
const {
  Input,
  Select,
  Button
} = window.AhtomicStudioDesignSystem_31497d;
const PAGE_LIST = ["Home", "Work", "Services", "About", "Contact"];

/* Mini live preview of the page hero, rendered from draft values */
function PagePreview({
  page,
  draft,
  accent
}) {
  const p = draft.pages[page];
  return /*#__PURE__*/React.createElement("div", {
    className: "ah-card",
    style: {
      padding: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "10px 14px",
      borderBottom: "1px solid var(--line-1)",
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, [0, 1, 2].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 8,
      height: 8,
      borderRadius: "50%",
      background: "var(--line-2)"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 8,
      fontFamily: "var(--font-mono)",
      fontSize: 10,
      color: "var(--text-disabled)"
    }
  }, "ahtomic.studio", page === "Home" ? "" : "/#" + page.toLowerCase())), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "36px 28px 40px",
      background: "radial-gradient(400px 180px at 50% 115%, " + accent + "26, transparent 70%)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 9.5,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 10
    }
  }, p.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.1
    }
  }, p.headline, " ", p.headlineAccent && /*#__PURE__*/React.createElement("em", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      letterSpacing: 0
    }
  }, p.headlineAccent), /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent
    }
  }, ".")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "12px 0 0",
      fontSize: 12.5,
      lineHeight: 1.6,
      color: "var(--text-secondary)",
      maxWidth: 340
    }
  }, p.intro), p.cta && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      marginTop: 18,
      padding: "8px 14px",
      borderRadius: "var(--radius-md)",
      background: accent,
      color: "#fff",
      fontSize: 11.5,
      fontWeight: 600
    }
  }, p.cta)));
}
function PagesEditor({
  draft,
  update
}) {
  const [page, setPage] = React.useState("Home");
  const p = draft.pages[page];
  const set = field => e => update(d => {
    d.pages[page][field] = e.target.value;
  });
  return /*#__PURE__*/React.createElement(EditorLayout, {
    preview: /*#__PURE__*/React.createElement(PagePreview, {
      page: page,
      draft: draft,
      accent: draft.appearance.accent
    })
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 6,
      flexWrap: "wrap"
    }
  }, PAGE_LIST.map(pg => /*#__PURE__*/React.createElement("button", {
    key: pg,
    type: "button",
    onClick: () => setPage(pg),
    style: {
      cursor: "pointer",
      font: "inherit",
      fontSize: 13,
      fontWeight: 500,
      padding: "7px 14px",
      borderRadius: 999,
      border: "1px solid " + (page === pg ? "var(--line-accent)" : "var(--line-1)"),
      background: page === pg ? "var(--accent-subtle)" : "transparent",
      color: page === pg ? "var(--text-body)" : "var(--text-muted)",
      transition: "all 140ms var(--ease-out)"
    }
  }, pg))), /*#__PURE__*/React.createElement(SectionCard, {
    title: page + " — headline",
    hint: "The big line at the top of the page. The italic word is set in the serif accent face."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Headline",
    value: p.headline,
    onChange: set("headline")
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Italic accent word",
    hint: "Leave empty for none",
    value: p.headlineAccent,
    onChange: set("headlineAccent")
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Section label",
    hint: "The small uppercase label above the headline",
    value: p.label,
    onChange: set("label")
  })), /*#__PURE__*/React.createElement(SectionCard, {
    title: page + " — copy"
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Intro paragraph",
    textarea: true,
    rows: 4,
    value: p.intro,
    onChange: set("intro")
  }), p.cta !== undefined && /*#__PURE__*/React.createElement(Input, {
    label: "Button text (call to action)",
    value: p.cta,
    onChange: set("cta"),
    style: {
      maxWidth: 320
    }
  })));
}
Object.assign(window, {
  PagesEditor
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/AdminPages.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/AdminProjects.jsx
try { (() => {
const {
  Input,
  Button,
  Badge,
  Tag,
  Switch,
  IconButton
} = window.AhtomicStudioDesignSystem_31497d;
function ProjectsEditor({
  draft,
  update
}) {
  const [editing, setEditing] = React.useState(null); // index being edited
  const projects = draft.projects;
  const move = (i, dir) => update(d => {
    const j = i + dir;
    if (j < 0 || j >= d.projects.length) return;
    const [it] = d.projects.splice(i, 1);
    d.projects.splice(j, 0, it);
  });
  const setField = (i, field) => e => update(d => {
    d.projects[i][field] = e.target.value;
  });
  const addProject = () => {
    update(d => {
      d.projects.push({
        title: "New project",
        meta: "Web app",
        tags: ["Web"],
        blurb: "",
        live: false,
        visible: true
      });
    });
    setEditing(projects.length);
  };
  return /*#__PURE__*/React.createElement(EditorLayout, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13.5,
      color: "var(--text-muted)"
    }
  }, "Shown on the Work page and the home page grid, in this order."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: addProject
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "Plus",
    size: 15,
    style: {
      marginRight: 6,
      verticalAlign: "-2px"
    }
  }), "Add project")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, projects.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "ah-card ah-card--pad-md",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      opacity: p.visible ? 1 : 0.55
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => move(i, -1),
    disabled: i === 0,
    "aria-label": "Move " + p.title + " up",
    style: {
      all: "unset",
      cursor: i === 0 ? "default" : "pointer",
      color: i === 0 ? "var(--text-disabled)" : "var(--text-muted)",
      lineHeight: 0,
      padding: 2
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ChevronUp",
    size: 15
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => move(i, 1),
    disabled: i === projects.length - 1,
    "aria-label": "Move " + p.title + " down",
    style: {
      all: "unset",
      cursor: i === projects.length - 1 ? "default" : "pointer",
      color: i === projects.length - 1 ? "var(--text-disabled)" : "var(--text-muted)",
      lineHeight: 0,
      padding: 2
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ChevronDown",
    size: 15
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "baseline",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, p.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      color: "var(--text-muted)"
    }
  }, p.meta), p.live ? /*#__PURE__*/React.createElement(Badge, {
    tone: "positive",
    dot: true
  }, "Live") : /*#__PURE__*/React.createElement(Badge, {
    tone: "warning",
    dot: true
  }, "In progress")), /*#__PURE__*/React.createElement(Switch, {
    label: p.visible ? "Shown" : "Hidden",
    checked: p.visible,
    onChange: e => update(d => {
      d.projects[i].visible = e.target.checked;
    })
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setEditing(editing === i ? null : i)
  }, editing === i ? "Close" : "Edit")), editing === i && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      borderTop: "1px solid var(--line-1)",
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Project name",
    value: p.title,
    onChange: setField(i, "title")
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Type line",
    hint: "e.g. \"Web app \xB7 Live\"",
    value: p.meta,
    onChange: setField(i, "meta")
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Description",
    textarea: true,
    rows: 3,
    value: p.blurb,
    onChange: setField(i, "blurb")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 20,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Mark as live",
    checked: p.live,
    onChange: e => update(d => {
      d.projects[i].live = e.target.checked;
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 6
    }
  }, p.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t))), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    style: {
      marginLeft: "auto",
      color: "var(--danger)"
    },
    onClick: () => {
      setEditing(null);
      update(d => {
        d.projects.splice(i, 1);
      });
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "Trash2",
    size: 14,
    style: {
      marginRight: 6,
      verticalAlign: "-2px"
    }
  }), "Delete project")))))));
}
Object.assign(window, {
  ProjectsEditor
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/AdminProjects.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/admin-shared.jsx
try { (() => {
const {
  Wordmark,
  Button,
  Badge,
  Tooltip
} = window.AhtomicStudioDesignSystem_31497d;

/* Lucide icon rendered natively in React from the UMD icon data (no createIcons DOM churn) */
function Icon({
  name,
  size = 16,
  stroke = 1.5,
  style
}) {
  const def = window.lucide && window.lucide.icons && window.lucide.icons[name] || null;
  if (!def) return null;
  const renderNode = (n, i) => {
    if (!Array.isArray(n)) return null;
    const [tag, attrs = {}, children = []] = n;
    return React.createElement(tag, {
      key: i,
      ...attrs
    }, Array.isArray(children) && children.length ? children.map(renderNode) : null);
  };
  // Two known shapes: a full ["svg", attrs, children] element triple, or a list of [tag, attrs] pairs
  const children = typeof def[0] === "string" ? Array.isArray(def[2]) ? def[2] : [] : def;
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    style: {
      flexShrink: 0,
      ...style
    }
  }, children.map(renderNode));
}
const ADMIN_SECTIONS = [{
  id: "pages",
  label: "Pages",
  icon: "FileText",
  desc: "Edit headlines and copy"
}, {
  id: "projects",
  label: "Projects",
  icon: "FolderOpen",
  desc: "Manage portfolio work"
}, {
  id: "appearance",
  label: "Appearance",
  icon: "Palette",
  desc: "Colors, effects, motion"
}, {
  id: "settings",
  label: "Settings",
  icon: "Settings",
  desc: "Contact and site details"
}];
function AdminSidebar({
  section,
  setSection
}) {
  return /*#__PURE__*/React.createElement("aside", {
    "aria-label": "Dashboard sections",
    style: {
      width: 248,
      flexShrink: 0,
      borderRight: "1px solid var(--line-1)",
      display: "flex",
      flexDirection: "column",
      background: "var(--black-900)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 20px 16px",
      borderBottom: "1px solid var(--line-1)"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 16,
    sub: "Site dashboard",
    href: "#"
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      padding: 12
    }
  }, ADMIN_SECTIONS.map(s => {
    const active = section === s.id;
    return /*#__PURE__*/React.createElement("button", {
      key: s.id,
      type: "button",
      onClick: () => setSection(s.id),
      "aria-current": active ? "page" : undefined,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        textAlign: "left",
        cursor: "pointer",
        padding: "10px 12px",
        borderRadius: "var(--radius-md)",
        border: "1px solid transparent",
        background: active ? "var(--surface-raised)" : "transparent",
        borderColor: active ? "var(--line-1)" : "transparent",
        color: active ? "var(--text-body)" : "var(--text-muted)",
        font: "inherit",
        fontSize: 14,
        fontWeight: 500,
        transition: "background 140ms var(--ease-out), color 140ms var(--ease-out)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: s.icon,
      size: 17,
      style: {
        color: active ? "var(--text-accent)" : "currentColor"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 2
      }
    }, s.label, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11.5,
        fontWeight: 400,
        color: "var(--text-disabled)"
      }
    }, s.desc)));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      padding: 16,
      borderTop: "1px solid var(--line-1)",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "../website/index.html",
    target: "_blank",
    rel: "noreferrer",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: 13,
      fontWeight: 500,
      color: "var(--text-secondary)",
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ExternalLink",
    size: 15
  }), " View live site"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 10.5,
      letterSpacing: "0.06em",
      color: "var(--text-disabled)"
    }
  }, "ahtomicstudio@gmail.com")));
}
function AdminTopbar({
  title,
  dirty,
  onSave,
  onDiscard,
  onPublish,
  savedAt
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 64,
      flexShrink: 0,
      borderBottom: "1px solid var(--line-1)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 24px",
      background: "rgba(10,10,11,0.75)",
      backdropFilter: "blur(12px)",
      position: "sticky",
      top: 0,
      zIndex: 30
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 17,
      fontWeight: 600,
      letterSpacing: "var(--tracking-tight)"
    }
  }, title), dirty ? /*#__PURE__*/React.createElement(Badge, {
    tone: "warning",
    dot: true
  }, "Unsaved changes") : savedAt ? /*#__PURE__*/React.createElement(Badge, {
    tone: "positive",
    dot: true
  }, "All changes saved") : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: onDiscard,
    disabled: !dirty
  }, "Discard changes"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: onSave,
    disabled: !dirty
  }, "Save draft"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: onPublish
  }, "Publish site")));
}

/* Two-column layout helper: form on the left, live preview on the right (stacks when narrow) */
function EditorLayout({
  children,
  preview
}) {
  const [wide, setWide] = React.useState(() => window.innerWidth >= 1150);
  React.useEffect(() => {
    const mq = window.matchMedia("(min-width: 1150px)");
    const onChange = e => setWide(e.matches);
    mq.addEventListener("change", onChange);
    setWide(mq.matches);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  const two = preview && wide;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: two ? "minmax(0, 1fr) minmax(0, 440px)" : "minmax(0, 1fr)",
      gap: 24,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20,
      minWidth: 0
    }
  }, children), preview && /*#__PURE__*/React.createElement("div", {
    style: {
      position: two ? "sticky" : "static",
      top: 88,
      minWidth: 0,
      order: two ? 0 : -1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginBottom: 10,
      color: "var(--text-muted)",
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "Eye",
    size: 13
  }), " Live preview"), preview));
}
function SectionCard({
  title,
  hint,
  children
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "ah-card ah-card--pad-lg",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 15,
      fontWeight: 600,
      letterSpacing: "var(--tracking-tight)"
    }
  }, title), hint && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "4px 0 0",
      fontSize: 12.5,
      color: "var(--text-muted)"
    }
  }, hint)), children);
}
Object.assign(window, {
  Icon,
  AdminSidebar,
  AdminTopbar,
  EditorLayout,
  SectionCard,
  ADMIN_SECTIONS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/admin-shared.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/About.jsx
try { (() => {
const {
  SectionLabel,
  Button,
  Card
} = window.AhtomicStudioDesignSystem_31497d;
function CountUp({
  to
}) {
  const [n, setN] = React.useState(0);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([en]) => {
      if (!en.isIntersecting) return;
      io.disconnect();
      const target = parseInt(to, 10);
      const t0 = performance.now();
      const dur = 900;
      const tick = t => {
        const p = Math.min(1, (t - t0) / dur);
        setN(Math.round(target * (1 - Math.pow(1 - p, 3))));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }, {
      threshold: 0.4
    });
    io.observe(el);
    return () => io.disconnect();
  }, [to]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref
  }, n);
}
function AboutPage({
  go
}) {
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 140,
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    index: "01"
  }, "About"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "24px 0 0",
      fontSize: 52,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.05
    }
  }, "A small studio, on ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      letterSpacing: 0
    }
  }, "purpose"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, ".")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      display: "flex",
      flexDirection: "column",
      gap: 20,
      fontSize: 16,
      lineHeight: 1.7,
      color: "var(--text-secondary)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Ahtomic Studio builds websites and mobile apps from California. No account managers, no handoffs. One person directs every project \u2014 design, scope, quality \u2014 while AI agents handle the coding. You get agency output at studio speed."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "We take on a few projects at a time and stay with them. Most of our work is long relationships: ship, measure, improve.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 16,
      marginTop: 48
    }
  }, [["4", "products shipped or shipping"], ["1", "live and in use today"], ["1", "point of contact, always"]].map(([n, d], i) => /*#__PURE__*/React.createElement("div", {
    key: d,
    "data-reveal": true,
    style: {
      "--d": `${i * 90}ms`
    }
  }, /*#__PURE__*/React.createElement(Card, {
    className: "stat-card",
    style: {
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 34,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)"
    }
  }, /*#__PURE__*/React.createElement(CountUp, {
    to: n
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, ".")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-muted)",
      marginTop: 4
    }
  }, d))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 64,
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go("Contact")
  }, "Start a project"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: () => go("Work")
  }, "See the work"))));
}
Object.assign(window, {
  AboutPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/About.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Contact.jsx
try { (() => {
const {
  SectionLabel,
  Input,
  Select,
  Checkbox,
  Button,
  Toast,
  Card
} = window.AhtomicStudioDesignSystem_31497d;
function ContactPage() {
  const [sent, setSent] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [err, setErr] = React.useState("");
  const submit = () => {
    if (!email.includes("@")) {
      setErr("Enter a real email so we can reply.");
      return;
    }
    setErr("");
    setSent(true);
  };
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 140,
      display: "grid",
      gridTemplateColumns: "1fr 1.2fr",
      gap: 64
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionLabel, {
    index: "01"
  }, "Contact"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "24px 0 0",
      fontSize: 52,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.05
    }
  }, "Start a ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      letterSpacing: 0
    }
  }, "project"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, ".")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "20px 0 0",
      fontSize: 16,
      lineHeight: 1.7,
      color: "var(--text-secondary)"
    }
  }, "Tell us what you're building. A few sentences is plenty \u2014 we'll reply within two days with honest thoughts on scope, budget, and whether we're the right fit."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 40,
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", null, "California \xB7 Remote-friendly"), /*#__PURE__*/React.createElement("span", null, "Replies within 2 days"), /*#__PURE__*/React.createElement("a", {
    href: "mailto:ahtomicstudio@gmail.com",
    style: {
      color: "var(--text-secondary)",
      textDecoration: "none",
      textTransform: "none",
      letterSpacing: "0.02em"
    }
  }, "ahtomicstudio@gmail.com"))), /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    className: "contact-card"
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "positive"
  }, "Message sent. We'll be in touch."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: "var(--text-secondary)"
    }
  }, "Thanks. Check your inbox in a day or two."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: () => setSent(false)
  }, "Send another")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Name",
    placeholder: "Your name"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    placeholder: "you@company.com",
    value: email,
    onChange: e => setEmail(e.target.value),
    error: err
  })), /*#__PURE__*/React.createElement(Select, {
    label: "Budget",
    options: ["Under $10k", "$10–50k", "$50k+", "Not sure yet"]
  }), /*#__PURE__*/React.createElement(Input, {
    label: "About the project",
    textarea: true,
    placeholder: "What are you building?"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Website",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Mobile app"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Design / brand"
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: submit,
    style: {
      alignSelf: "flex-start"
    }
  }, "Send it")))));
}
Object.assign(window, {
  ContactPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Contact.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Home.jsx
try { (() => {
const {
  Button,
  SectionLabel,
  ProjectCard,
  Tag,
  Badge,
  Card
} = window.AhtomicStudioDesignSystem_31497d;
function HomePage({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("header", {
    style: {
      position: "relative",
      padding: "180px 0 120px",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: 780
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-reveal": true,
    style: {
      "--d": "0ms",
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 20
    }
  }, "Web studio \xB7 California"), /*#__PURE__*/React.createElement("h1", {
    "data-reveal": true,
    style: {
      "--d": "90ms",
      margin: 0,
      fontSize: 68,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)",
      lineHeight: "var(--leading-tight)"
    }
  }, "Everything, down to the ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-accent)"
    }
  }, "atom"), /*#__PURE__*/React.createElement("span", {
    className: "dot-pop"
  }, ".")), /*#__PURE__*/React.createElement("p", {
    "data-reveal": true,
    style: {
      "--d": "180ms",
      margin: "24px 0 0",
      fontSize: 18,
      lineHeight: 1.6,
      color: "var(--text-secondary)",
      maxWidth: 520
    }
  }, "Small studio, serious software. One person directs every project; AI agents handle the build. Fast, focused, no agency overhead."), /*#__PURE__*/React.createElement("div", {
    "data-reveal": true,
    style: {
      "--d": "260ms",
      display: "flex",
      gap: 12,
      marginTop: 36
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go("Contact")
  }, "Start a project"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: () => go("Work")
  }, "View work"))))), /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement("div", {
    "data-reveal": true
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    index: "01"
  }, "Selected work")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 20,
      marginTop: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-reveal": true,
    style: {
      "--d": "80ms"
    }
  }, /*#__PURE__*/React.createElement(ProjectCard, {
    title: "CannaPickForMe",
    meta: "Web app \xB7 Live",
    image: "../../assets/portfolio/cannapickforme/home.png",
    onClick: e => {
      e.preventDefault();
      go("Work");
    }
  })), /*#__PURE__*/React.createElement("div", {
    "data-reveal": true,
    style: {
      "--d": "160ms"
    }
  }, /*#__PURE__*/React.createElement(ProjectCard, {
    title: "A Chalkboard for Two",
    meta: "Web app",
    image: "../../assets/portfolio/chalkboard/landing.png",
    onClick: e => {
      e.preventDefault();
      go("Work");
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: () => go("Work")
  }, "All work \u2192"))), /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 96
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-reveal": true
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    index: "02"
  }, "What we do")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 20,
      marginTop: 32
    }
  }, [["Websites", "Marketing sites and web apps. Fast, accessible, maintained."], ["Mobile apps", "iOS and Android products, from concept to store."], ["Design & brand", "Interfaces, identities, and the systems behind them."]].map(([t, d], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    "data-reveal": true,
    style: {
      "--d": `${i * 90}ms`
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    interactive: true,
    style: {
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      marginBottom: 8
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: "var(--text-secondary)",
      lineHeight: 1.55
    }
  }, d))))))));
}
Object.assign(window, {
  HomePage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Services.jsx
try { (() => {
const {
  SectionLabel,
  Card,
  Button
} = window.AhtomicStudioDesignSystem_31497d;
const SERVICES = [["01", "Websites", "Marketing sites, web apps, and everything between. Built fast, built to last, easy to update.", ["Next.js / modern web", "Performance & SEO", "CMS when you need one"]], ["02", "Mobile apps", "iOS and Android products from first sketch to the app store, including the backend behind them.", ["Native feel", "Store submission", "Analytics wired in"]], ["03", "Design & brand", "Interfaces, identity, and design systems — designed and shipped under one direction.", ["UI/UX design", "Design systems", "Brand foundations"]]];
function ServicesPage({
  go
}) {
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 140
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    index: "01"
  }, "Services"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "24px 0 0",
      fontSize: 52,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.05
    }
  }, "Design, build, ship", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "."), " ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      letterSpacing: 0
    }
  }, "Usually all three.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16,
      marginTop: 48
    }
  }, SERVICES.map(([n, title, body, points], i) => /*#__PURE__*/React.createElement("div", {
    key: n,
    "data-reveal": true,
    style: {
      "--d": `${i * 90}ms`
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    className: "svc-row"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "80px 1.2fr 1fr",
      gap: 24,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "svc-index",
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 13,
      color: "var(--text-accent)"
    }
  }, n), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 600,
      letterSpacing: "var(--tracking-tight)"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "8px 0 0",
      fontSize: 14,
      color: "var(--text-secondary)",
      lineHeight: 1.55
    }
  }, body)), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none",
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, points.map(pt => /*#__PURE__*/React.createElement("li", {
    key: pt,
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      display: "flex",
      gap: 10,
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-accent)"
    }
  }, "\u2192"), pt)))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 64,
      borderTop: "1px solid var(--line-1)",
      paddingTop: 32,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 16,
      color: "var(--text-secondary)",
      maxWidth: 480
    }
  }, "Not sure which of these you need? That's normal. Tell us what you're building and we'll figure it out together."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go("Contact")
  }, "Start a project"))));
}
Object.assign(window, {
  ServicesPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Services.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Work.jsx
try { (() => {
const {
  SectionLabel,
  ProjectCard,
  Tabs,
  Tag,
  Badge,
  Card,
  Button
} = window.AhtomicStudioDesignSystem_31497d;
const PROJECTS = [{
  title: "CannaPickForMe",
  meta: "Web app · Live",
  tags: ["Web"],
  image: "../../assets/portfolio/cannapickforme/home.png",
  live: true,
  blurb: "A strain matcher for adults 21+. Four questions, one personalized pick from 200+ strains. Dispensaries pay monthly to reach its users."
}, {
  title: "A Chalkboard for Two",
  meta: "Web app",
  tags: ["Web"],
  image: "../../assets/portfolio/chalkboard/landing.png",
  blurb: "One shared chalkboard, split down the middle. Built for leaving little notes between two people over a private link."
}, {
  title: "Snapacat",
  meta: "Mobile app · In progress",
  tags: ["Mobile"],
  blurb: "Log photos and notes of neighborhood cats; the app turns each cat into a sprite you can collect in customized environments."
}, {
  title: "BudSnap",
  meta: "Mobile app · In progress",
  tags: ["Mobile"],
  blurb: "A living Pokédex for cannabis. A fun way of logging for a forgetful demographic."
}];
function WorkPage({
  go
}) {
  const [filter, setFilter] = React.useState("All");
  const shown = PROJECTS.filter(p => filter === "All" || p.tags.includes(filter));
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 140
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    index: "01"
  }, "Selected work"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "24px 0 0",
      fontSize: 52,
      fontWeight: 700,
      letterSpacing: "var(--tracking-display)",
      lineHeight: 1.05
    }
  }, "Work"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "16px 0 32px",
      fontSize: 16,
      color: "var(--text-secondary)",
      maxWidth: 520
    }
  }, "Four products so far. One live, three in the works."), /*#__PURE__*/React.createElement(Tabs, {
    tabs: ["All", "Web", "Mobile"],
    value: filter,
    onChange: setFilter
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 20,
      marginTop: 32
    }
  }, shown.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: p.title,
    "data-reveal": true,
    className: "ah-card ah-card--pad-md work-tile",
    style: {
      "--d": `${i % 2 * 90}ms`,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, p.image ? /*#__PURE__*/React.createElement("img", {
    src: p.image,
    alt: p.title,
    style: {
      width: "100%",
      aspectRatio: "16/10",
      objectFit: "cover",
      objectPosition: "top",
      borderRadius: "var(--radius-md)",
      border: "1px solid var(--line-1)",
      display: "block"
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      aspectRatio: "16/10",
      borderRadius: "var(--radius-md)",
      border: "1px dashed var(--line-2)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      color: "var(--text-disabled)"
    }
  }, "No public screens yet"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 19,
      fontWeight: 600
    }
  }, p.title), p.live ? /*#__PURE__*/React.createElement(Badge, {
    tone: "positive",
    dot: true
  }, "Live") : /*#__PURE__*/React.createElement(Badge, {
    tone: "warning",
    dot: true
  }, "In progress")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: "var(--text-secondary)",
      lineHeight: 1.55
    }
  }, p.blurb), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 6
    }
  }, p.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t))), p.live && /*#__PURE__*/React.createElement("a", {
    href: "https://cannapickforme.com",
    target: "_blank",
    rel: "noreferrer",
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: "var(--text-body)",
      textDecoration: "none"
    }
  }, "Visit ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-accent)"
    }
  }, "\u2197")))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 64,
      display: "flex",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go("Contact")
  }, "Start a project"))));
}
Object.assign(window, {
  WorkPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Work.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/shared.jsx
try { (() => {
const {
  Wordmark,
  Button
} = window.AhtomicStudioDesignSystem_31497d;
function Nav({
  page,
  go
}) {
  const links = ["Home", "Work", "Services", "About"];
  return /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Main",
    style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 40,
      background: "rgba(10,10,11,0.75)",
      backdropFilter: "blur(12px)",
      borderBottom: "1px solid var(--line-1)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--container-pad)",
      height: 64,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 18,
    href: "#home",
    "aria-label": "Ahtomic Studio \u2014 home"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 4
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: `#${l.toLowerCase()}`,
    className: "nav-link",
    "data-active": String(page === l),
    "aria-current": page === l ? "page" : undefined,
    onClick: e => {
      e.preventDefault();
      go(l);
    },
    style: {
      textDecoration: "none",
      fontSize: 14,
      fontWeight: 500,
      padding: "8px 12px",
      borderRadius: 8,
      color: page === l ? "var(--text-body)" : "var(--text-muted)",
      transition: "color 140ms var(--ease-out)"
    }
  }, l)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: () => go("Contact"),
    style: {
      marginLeft: 12
    }
  }, "Start a project"))));
}
function Footer({
  go
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: "1px solid var(--line-1)",
      marginTop: 128
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "48px var(--container-pad)",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 16,
    sub: "Studio \xB7 California"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--text-muted)"
    }
  }, "Websites and mobile apps, designed and built.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 20,
      alignItems: "center"
    }
  }, ["Work", "Services", "About", "Contact"].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: `#${l.toLowerCase()}`,
    onClick: e => {
      e.preventDefault();
      go(l);
    },
    style: {
      fontSize: 13,
      color: "var(--text-muted)",
      textDecoration: "none",
      padding: "6px 0"
    }
  }, l)), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascot/thom.png",
    alt: "Thom",
    title: "Thom says hi",
    className: "thom",
    style: {
      height: 36,
      width: "auto",
      opacity: 0.9
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--line-1)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "16px var(--container-pad)",
      display: "flex",
      justifyContent: "space-between",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "0.06em",
      color: "var(--text-disabled)"
    }
  }, "\xA9 2026 Ahtomic Studio"), /*#__PURE__*/React.createElement("a", {
    href: "mailto:ahtomicstudio@gmail.com",
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "0.06em",
      color: "var(--text-muted)",
      textDecoration: "none"
    }
  }, "ahtomicstudio@gmail.com"))));
}
function BackToTop() {
  const [show, setShow] = React.useState(false);
  React.useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        setShow(window.scrollY > 600);
        raf = 0;
      });
    };
    window.addEventListener("scroll", onScroll, {
      passive: true
    });
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "back-to-top",
    "data-show": String(show),
    "aria-label": "Back to top",
    "aria-hidden": String(!show),
    tabIndex: show ? 0 : -1,
    onClick: () => window.scrollTo({
      top: 0,
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth"
    })
  }, "\u2191");
}
function Page({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--container-pad)"
    }
  }, children);
}
Object.assign(window, {
  Nav,
  Footer,
  Page,
  BackToTop
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/shared.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.ProjectCard = __ds_scope.ProjectCard;

__ds_ns.SectionLabel = __ds_scope.SectionLabel;

__ds_ns.Wordmark = __ds_scope.Wordmark;

})();
