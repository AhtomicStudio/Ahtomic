const { SectionLabel, Input, Select, Checkbox, Button, Toast, Card } = window.AhtomicStudioDesignSystem_31497d;

function ContactPage() {
  const [sent, setSent] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [err, setErr] = React.useState("");
  const submit = () => {
    if (!email.includes("@")) { setErr("Enter a real email so we can reply."); return; }
    setErr("");
    setSent(true);
  };
  return (
    <Page>
      <div style={{ paddingTop: 140, display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 64 }}>
        <div>
          <SectionLabel index="01">Contact</SectionLabel>
          <h1 style={{ margin: "24px 0 0", fontSize: 52, fontWeight: 700, letterSpacing: "var(--tracking-display)", lineHeight: 1.05 }}>
            Start a <em style={{ fontFamily: "var(--font-display)", fontWeight: 400, letterSpacing: 0 }}>project</em><span style={{ color: "var(--accent)" }}>.</span>
          </h1>
          <p style={{ margin: "20px 0 0", fontSize: 16, lineHeight: 1.7, color: "var(--text-secondary)" }}>Tell us what you're building. A few sentences is plenty — we'll reply within two days with honest thoughts on scope, budget, and whether we're the right fit.</p>
          <div style={{ marginTop: 40, fontFamily: "var(--font-mono)", fontSize: 12, letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-muted)", display: "flex", flexDirection: "column", gap: 10 }}>
            <span>California · Remote-friendly</span>
            <span>Replies within 2 days</span>
            <a href="mailto:ahtomicstudio@gmail.com" style={{ color: "var(--text-secondary)", textDecoration: "none", textTransform: "none", letterSpacing: "0.02em" }}>ahtomicstudio@gmail.com</a>
          </div>
        </div>
        <Card padding="lg" className="contact-card">
          {sent ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 16, alignItems: "flex-start" }}>
              <Toast tone="positive">Message sent. We'll be in touch.</Toast>
              <p style={{ margin: 0, fontSize: 14, color: "var(--text-secondary)" }}>Thanks. Check your inbox in a day or two.</p>
              <Button variant="secondary" size="sm" onClick={() => setSent(false)}>Send another</Button>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <Input label="Name" placeholder="Your name" />
                <Input label="Email" placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} error={err} />
              </div>
              <Select label="Budget" options={["Under $10k", "$10–50k", "$50k+", "Not sure yet"]} />
              <Input label="About the project" textarea placeholder="What are you building?" />
              <div style={{ display: "flex", gap: 20 }}>
                <Checkbox label="Website" defaultChecked />
                <Checkbox label="Mobile app" />
                <Checkbox label="Design / brand" />
              </div>
              <Button variant="primary" size="lg" onClick={submit} style={{ alignSelf: "flex-start" }}>Send it</Button>
            </div>
          )}
        </Card>
      </div>
    </Page>
  );
}

Object.assign(window, { ContactPage });
