const { SectionLabel, Card, Button } = window.AhtomicStudioDesignSystem_31497d;

const SERVICES = [
  ["01", "Websites", "Marketing sites, web apps, and everything between. Built fast, built to last, easy to update.", ["Next.js / modern web", "Performance & SEO", "CMS when you need one"]],
  ["02", "Mobile apps", "iOS and Android products from first sketch to the app store, including the backend behind them.", ["Native feel", "Store submission", "Analytics wired in"]],
  ["03", "Design & brand", "Interfaces, identity, and design systems — designed and shipped under one direction.", ["UI/UX design", "Design systems", "Brand foundations"]],
];

function ServicesPage({ go }) {
  return (
    <Page>
      <div style={{ paddingTop: 140 }}>
        <SectionLabel index="01">Services</SectionLabel>
        <h1 style={{ margin: "24px 0 0", fontSize: 52, fontWeight: 700, letterSpacing: "var(--tracking-display)", lineHeight: 1.05 }}>
          Design, build, ship<span style={{ color: "var(--accent)" }}>.</span> <em style={{ fontFamily: "var(--font-display)", fontWeight: 400, letterSpacing: 0 }}>Usually all three.</em>
        </h1>
        <div style={{ display: "flex", flexDirection: "column", gap: 16, marginTop: 48 }}>
          {SERVICES.map(([n, title, body, points], i) => (
            <div key={n} data-reveal style={{ "--d": `${i * 90}ms` }}>
              <Card padding="lg" className="svc-row">
                <div style={{ display: "grid", gridTemplateColumns: "80px 1.2fr 1fr", gap: 24, alignItems: "start" }}>
                  <span className="svc-index" style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--text-accent)" }}>{n}</span>
                  <div>
                    <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: "var(--tracking-tight)" }}>{title}</div>
                    <p style={{ margin: "8px 0 0", fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.55 }}>{body}</p>
                  </div>
                  <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 8 }}>
                    {points.map((pt) => (
                      <li key={pt} style={{ fontSize: 13, color: "var(--text-secondary)", display: "flex", gap: 10, alignItems: "baseline" }}>
                        <span style={{ color: "var(--text-accent)" }}>→</span>{pt}
                      </li>
                    ))}
                  </ul>
                </div>
              </Card>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 64, borderTop: "1px solid var(--line-1)", paddingTop: 32, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 24 }}>
          <p style={{ margin: 0, fontSize: 16, color: "var(--text-secondary)", maxWidth: 480 }}>Not sure which of these you need? That's normal. Tell us what you're building and we'll figure it out together.</p>
          <Button variant="primary" size="lg" onClick={() => go("Contact")}>Start a project</Button>
        </div>
      </div>
    </Page>
  );
}

Object.assign(window, { ServicesPage });
