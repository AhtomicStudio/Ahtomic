const { Wordmark, Button } = window.AhtomicStudioDesignSystem_31497d;

function Nav({ page, go }) {
  const links = ["Home", "Work", "Services", "About"];
  return (
    <nav aria-label="Main" style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 40,
      background: "rgba(10,10,11,0.75)", backdropFilter: "blur(12px)",
      borderBottom: "1px solid var(--line-1)",
    }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--container-pad)", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Wordmark size={18} href="#home" aria-label="Ahtomic Studio — home" />
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          {links.map((l) => (
            <a key={l} href={`#${l.toLowerCase()}`} className="nav-link" data-active={String(page === l)} aria-current={page === l ? "page" : undefined} onClick={(e) => { e.preventDefault(); go(l); }}
              style={{
                textDecoration: "none", fontSize: 14, fontWeight: 500, padding: "8px 12px", borderRadius: 8,
                color: page === l ? "var(--text-body)" : "var(--text-muted)",
                transition: "color 140ms var(--ease-out)",
              }}>{l}</a>
          ))}
          <Button variant="primary" size="sm" onClick={() => go("Contact")} style={{ marginLeft: 12 }}>Start a project</Button>
        </div>
      </div>
    </nav>
  );
}

function Footer({ go }) {
  return (
    <footer style={{ borderTop: "1px solid var(--line-1)", marginTop: 128 }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "48px var(--container-pad)", display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 24 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <Wordmark size={16} sub="Studio · California" />
          <span style={{ fontSize: 13, color: "var(--text-muted)" }}>Websites and mobile apps, designed and built.</span>
        </div>
        <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
          {["Work", "Services", "About", "Contact"].map((l) => (
            <a key={l} href={`#${l.toLowerCase()}`} onClick={(e) => { e.preventDefault(); go(l); }} style={{ fontSize: 13, color: "var(--text-muted)", textDecoration: "none", padding: "6px 0" }}>{l}</a>
          ))}
          <img src="../assets/mascot/thom.png" alt="Thom" title="Thom says hi" className="thom" style={{ height: 36, width: "auto", opacity: 0.9 }} />
        </div>
      </div>
      <div style={{ borderTop: "1px solid var(--line-1)" }}>
        <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "16px var(--container-pad)", display: "flex", justifyContent: "space-between", gap: 16 }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.06em", color: "var(--text-disabled)" }}>© 2026 Ahtomic Studio</span>
          <a href="mailto:ahtomicstudio@gmail.com" style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.06em", color: "var(--text-muted)", textDecoration: "none" }}>ahtomicstudio@gmail.com</a>
        </div>
      </div>
    </footer>
  );
}

function BackToTop() {
  const [show, setShow] = React.useState(false);
  React.useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => { setShow(window.scrollY > 600); raf = 0; });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => { window.removeEventListener("scroll", onScroll); if (raf) cancelAnimationFrame(raf); };
  }, []);
  return (
    <button type="button" className="back-to-top" data-show={String(show)} aria-label="Back to top" aria-hidden={String(!show)} tabIndex={show ? 0 : -1}
      onClick={() => window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" })}>
      ↑
    </button>
  );
}

function Page({ children }) {
  return (
    <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--container-pad)" }}>{children}</div>
  );
}

Object.assign(window, { Nav, Footer, Page, BackToTop });
