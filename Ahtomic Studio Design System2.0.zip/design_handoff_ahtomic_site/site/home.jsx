const { Button, SectionLabel, ProjectCard, Tag, Badge, Card } = window.AhtomicStudioDesignSystem_31497d;

function HomePage({ go }) {
  return (
    <div>
      <header style={{ position: "relative", padding: "180px 0 120px", overflow: "hidden" }}>
        <Page>
          <div style={{ position: "relative", maxWidth: 780 }}>
            <div data-reveal style={{ "--d": "0ms", fontFamily: "var(--font-mono)", fontSize: 12, letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 20 }}>Web studio · California</div>
            <h1 data-reveal style={{ "--d": "90ms", margin: 0, fontSize: 68, fontWeight: 700, letterSpacing: "var(--tracking-display)", lineHeight: "var(--leading-tight)" }}>
              Everything, down to the <span style={{ color: "var(--text-accent)" }}>atom</span><span className="dot-pop">.</span>
            </h1>
            <p data-reveal style={{ "--d": "180ms", margin: "24px 0 0", fontSize: 18, lineHeight: 1.6, color: "var(--text-secondary)", maxWidth: 520 }}>
              Small studio, serious software. One person directs every project; AI agents handle the build. Fast, focused, no agency overhead.
            </p>
            <div data-reveal style={{ "--d": "260ms", display: "flex", gap: 12, marginTop: 36 }}>
              <Button variant="primary" size="lg" onClick={() => go("Contact")}>Start a project</Button>
              <Button variant="secondary" size="lg" onClick={() => go("Work")}>View work</Button>
            </div>
          </div>
        </Page>
      </header>

      <Page>
        <div data-reveal><SectionLabel index="01">Selected work</SectionLabel></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginTop: 32 }}>
          <div data-reveal style={{ "--d": "80ms" }}><ProjectCard title="CannaPickForMe" meta="Web app · Live" image="../assets/portfolio/cannapickforme/home.png" onClick={(e) => { e.preventDefault(); go("Work"); }} /></div>
          <div data-reveal style={{ "--d": "160ms" }}><ProjectCard title="A Chalkboard for Two" meta="Web app" image="../assets/portfolio/chalkboard/landing.png" onClick={(e) => { e.preventDefault(); go("Work"); }} /></div>
        </div>
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 20 }}>
          <Button variant="ghost" onClick={() => go("Work")}>All work →</Button>
        </div>
      </Page>

      <Page>
        <div style={{ marginTop: 96 }}>
          <div data-reveal><SectionLabel index="02">What we do</SectionLabel></div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20, marginTop: 32 }}>
            {[
              ["Websites", "Marketing sites and web apps. Fast, accessible, maintained."],
              ["Mobile apps", "iOS and Android products, from concept to store."],
              ["Design & brand", "Interfaces, identities, and the systems behind them."],
            ].map(([t, d], i) => (
              <div key={t} data-reveal style={{ "--d": `${i * 90}ms` }}>
                <Card padding="lg" interactive style={{ height: "100%" }}>
                  <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>{t}</div>
                  <p style={{ margin: 0, fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.55 }}>{d}</p>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </Page>
    </div>
  );
}

Object.assign(window, { HomePage });
