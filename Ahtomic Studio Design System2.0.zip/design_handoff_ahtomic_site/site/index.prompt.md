"you talk to the people doing the work" makes it sound like I am the one coding. I am using ai agents to do all the coding. 
