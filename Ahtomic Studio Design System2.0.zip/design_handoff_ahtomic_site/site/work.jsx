const { SectionLabel, ProjectCard, Tabs, Tag, Badge, Card, Button } = window.AhtomicStudioDesignSystem_31497d;

const PROJECTS = [
  { title: "CannaPickForMe", meta: "Web app · Live", tags: ["Web"], image: "../assets/portfolio/cannapickforme/home.png", live: true,
    blurb: "A strain matcher for adults 21+. Four questions, one personalized pick from 200+ strains. Dispensaries pay monthly to reach its users." },
  { title: "A Chalkboard for Two", meta: "Web app", tags: ["Web"], image: "../assets/portfolio/chalkboard/landing.png",
    blurb: "One shared chalkboard, split down the middle. Built for leaving little notes between two people over a private link." },
  { title: "Snapacat", meta: "Mobile app · In progress", tags: ["Mobile"],
    blurb: "Log photos and notes of neighborhood cats; the app turns each cat into a sprite you can collect in customized environments." },
  { title: "BudSnap", meta: "Mobile app · In progress", tags: ["Mobile"],
    blurb: "A living Pokédex for cannabis. A fun way of logging for a forgetful demographic." },
];

function WorkPage({ go }) {
  const [filter, setFilter] = React.useState("All");
  const shown = PROJECTS.filter((p) => filter === "All" || p.tags.includes(filter));
  return (
    <Page>
      <div style={{ paddingTop: 140 }}>
        <SectionLabel index="01">Selected work</SectionLabel>
        <h1 style={{ margin: "24px 0 0", fontSize: 52, fontWeight: 700, letterSpacing: "var(--tracking-display)", lineHeight: 1.05 }}>Work</h1>
        <p style={{ margin: "16px 0 32px", fontSize: 16, color: "var(--text-secondary)", maxWidth: 520 }}>Four products so far. One live, three in the works.</p>
        <Tabs tabs={["All", "Web", "Mobile"]} value={filter} onChange={setFilter} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginTop: 32 }}>
          {shown.map((p, i) => (
            <div key={p.title} data-reveal className="ah-card ah-card--pad-md work-tile" style={{ "--d": `${(i % 2) * 90}ms`, display: "flex", flexDirection: "column", gap: 14 }}>
              {p.image ? (
                <img src={p.image} alt={p.title} style={{ width: "100%", aspectRatio: "16/10", objectFit: "cover", objectPosition: "top", borderRadius: "var(--radius-md)", border: "1px solid var(--line-1)", display: "block" }} />
              ) : (
                <div style={{ width: "100%", aspectRatio: "16/10", borderRadius: "var(--radius-md)", border: "1px dashed var(--line-2)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--text-disabled)" }}>No public screens yet</div>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 12 }}>
                <span style={{ fontSize: 19, fontWeight: 600 }}>{p.title}</span>
                {p.live ? <Badge tone="positive" dot>Live</Badge> : <Badge tone="warning" dot>In progress</Badge>}
              </div>
              <p style={{ margin: 0, fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.55 }}>{p.blurb}</p>
              <div style={{ display: "flex", gap: 8, alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", gap: 6 }}>{p.tags.map((t) => <Tag key={t}>{t}</Tag>)}</div>
                {p.live && <a href="https://cannapickforme.com" target="_blank" rel="noreferrer" style={{ fontSize: 13, fontWeight: 500, color: "var(--text-body)", textDecoration: "none" }}>Visit <span style={{ color: "var(--text-accent)" }}>↗</span></a>}
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 64, display: "flex", justifyContent: "center" }}>
          <Button variant="primary" size="lg" onClick={() => go("Contact")}>Start a project</Button>
        </div>
      </div>
    </Page>
  );
}

Object.assign(window, { WorkPage });
