const { SectionLabel, Button, Card } = window.AhtomicStudioDesignSystem_31497d;

function CountUp({ to }) {
  const [n, setN] = React.useState(0);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([en]) => {
      if (!en.isIntersecting) return;
      io.disconnect();
      const target = parseInt(to, 10);
      const t0 = performance.now();
      const dur = 900;
      const tick = (t) => {
        const p = Math.min(1, (t - t0) / dur);
        setN(Math.round(target * (1 - Math.pow(1 - p, 3))));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }, { threshold: 0.4 });
    io.observe(el);
    return () => io.disconnect();
  }, [to]);
  return <span ref={ref}>{n}</span>;
}

function AboutPage({ go }) {
  return (
    <Page>
      <div style={{ paddingTop: 140, maxWidth: 720 }}>
        <SectionLabel index="01">About</SectionLabel>
        <h1 style={{ margin: "24px 0 0", fontSize: 52, fontWeight: 700, letterSpacing: "var(--tracking-display)", lineHeight: 1.05 }}>
          A small studio, on <em style={{ fontFamily: "var(--font-display)", fontWeight: 400, letterSpacing: 0 }}>purpose</em><span style={{ color: "var(--accent)" }}>.</span>
        </h1>
        <div style={{ marginTop: 32, display: "flex", flexDirection: "column", gap: 20, fontSize: 16, lineHeight: 1.7, color: "var(--text-secondary)" }}>
          <p style={{ margin: 0 }}>Ahtomic Studio builds websites and mobile apps from California. No account managers, no handoffs. One person directs every project — design, scope, quality — while AI agents handle the coding. You get agency output at studio speed.</p>
          <p style={{ margin: 0 }}>We take on a few projects at a time and stay with them. Most of our work is long relationships: ship, measure, improve.</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginTop: 48 }}>
          {[["4", "products shipped or shipping"], ["1", "live and in use today"], ["1", "point of contact, always"]].map(([n, d], i) => (
            <div key={d} data-reveal style={{ "--d": `${i * 90}ms` }}>
              <Card className="stat-card" style={{ height: "100%" }}>
                <div style={{ fontSize: 34, fontWeight: 700, letterSpacing: "var(--tracking-display)" }}><CountUp to={n} /><span style={{ color: "var(--accent)" }}>.</span></div>
                <div style={{ fontSize: 13, color: "var(--text-muted)", marginTop: 4 }}>{d}</div>
              </Card>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 64, display: "flex", gap: 12 }}>
          <Button variant="primary" size="lg" onClick={() => go("Contact")}>Start a project</Button>
          <Button variant="secondary" size="lg" onClick={() => go("Work")}>See the work</Button>
        </div>
      </div>
    </Page>
  );
}

Object.assign(window, { AboutPage });
