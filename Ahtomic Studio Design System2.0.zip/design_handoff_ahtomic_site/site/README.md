# Ahtomic Studio — marketing site UI kit

Interactive click-through of the studio's own site: Home, Work, Services, About, Contact. Composes the system primitives from `_ds_bundle.js`; portfolio imagery is real screenshots from `assets/portfolio/`. Snapacat and BudSnap have no public screens yet, so their tiles are deliberately imageless.

Files: `index.html` (shell + nav state) · `shared.jsx` (Nav, Footer) · one JSX per page.
